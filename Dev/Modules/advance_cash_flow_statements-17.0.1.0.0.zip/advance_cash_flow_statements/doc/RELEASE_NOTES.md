## Module <advance_cash_flow_statements>

#### 04.04.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Advanced Cash Flow Statements
