## Module <whatsapp_product_inquiry>
#### 08.04.2024
#### Version 17.0.1.0.0
#### ADD

- Initial commit for Whatsapp Product Inquiry In Website
