# -*- coding: utf-8 -*-
# Copyright (C) Wisenetic Technologies.

from . import product_size_chart, product_template, product_category
