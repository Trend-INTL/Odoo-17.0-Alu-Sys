This module helps users to manage signature for the user.


Screenshots
^^^^^^^^^^^

.. image:: https://apps.odoocdn.com/apps/assets/17.0/users_signature/screenshots/screenshot_1.png
    :alt: User Signature
    :width: 100%
