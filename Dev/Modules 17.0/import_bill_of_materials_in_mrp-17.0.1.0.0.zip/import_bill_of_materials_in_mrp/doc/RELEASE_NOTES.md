## Module <import_bill_of_materials_in_mrp>

#### 14.05.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Import Bill Of Materials
