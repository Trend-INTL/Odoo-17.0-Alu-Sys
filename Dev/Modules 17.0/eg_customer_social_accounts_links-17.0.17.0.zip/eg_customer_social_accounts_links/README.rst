=================================
Social Media Links
=================================
This odoo module will help the user to add the social media account link's also, get visible in the kanban view.