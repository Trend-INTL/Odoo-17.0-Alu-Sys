{
    'name': 'Social Media Links',
    'version': '17.0',
    'category': 'customer',
    'summery': 'Social Media Links',
    'author': 'INKERP',
    'website': "https://www.INKERP.com",
    'depends': ['base'],

    'data': [
        'views/res_partner_view.xml',
    ],

    'images': ['static/description/banner.png'],
    'license': "OPL-1",
    'installable': True,
    'application': True,
    'auto_install': False,
}
