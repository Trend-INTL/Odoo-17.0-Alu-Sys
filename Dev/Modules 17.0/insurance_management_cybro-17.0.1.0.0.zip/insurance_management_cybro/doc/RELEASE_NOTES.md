## Module <insurance_management_cybro>

#### 12.12.2023
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Insurance Management
