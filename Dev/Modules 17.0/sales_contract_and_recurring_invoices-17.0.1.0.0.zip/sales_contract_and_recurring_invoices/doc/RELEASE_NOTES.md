## Module <sales_contract_and_recurring_invoices>

#### 27.03.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Sales Contract and Recurring Invoices
