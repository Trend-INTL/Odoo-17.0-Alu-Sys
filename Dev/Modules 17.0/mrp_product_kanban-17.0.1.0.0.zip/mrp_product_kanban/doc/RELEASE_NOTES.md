## Module <mrp_product_kanban>

#### 01.06.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Manufacturing Product Kanban
