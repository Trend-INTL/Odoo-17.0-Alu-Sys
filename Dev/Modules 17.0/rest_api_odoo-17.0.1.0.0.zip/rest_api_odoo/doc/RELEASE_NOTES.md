## Module <rest_api_odoo>

#### 16.04.2024
#### Version 17.0.1.0.0
 - Initial Commit for Odoo rest API
