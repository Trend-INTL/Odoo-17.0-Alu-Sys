## Module <whatsapp_chat_layout>

#### 23.02.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Whatsapp Chat Layout in Odoo Discuss