# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import inherit_sale_order


