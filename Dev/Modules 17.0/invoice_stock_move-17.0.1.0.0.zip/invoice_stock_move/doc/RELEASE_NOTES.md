## Module <invoice_stock_move>

#### 19.12.2023
#### Version 17.0.1.0.0
#### ADD

Initial Commit for Stock Picking From Invoice
