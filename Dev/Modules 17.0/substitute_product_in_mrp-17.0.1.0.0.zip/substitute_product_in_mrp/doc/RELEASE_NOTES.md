## Module <substitute_product_in_mrp>

#### 18.05.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for MRP Substitutes Products
