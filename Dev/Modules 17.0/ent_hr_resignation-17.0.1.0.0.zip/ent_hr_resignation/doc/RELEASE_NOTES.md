## Module <ent_hr_resignation>

#### 01.02.2024
#### Version 17.0.1.0.0
##### ADD

- Initial Commit for Enterprise OpenHRMS Resignation
