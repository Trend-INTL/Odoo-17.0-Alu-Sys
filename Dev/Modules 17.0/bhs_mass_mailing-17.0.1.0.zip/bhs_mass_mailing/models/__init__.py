# -*- coding: utf-8 -*-

from . import mailing, mailing_contacted