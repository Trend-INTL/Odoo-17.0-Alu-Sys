# from . import product_pricelist
from . import product_product
from . import product_product_kit