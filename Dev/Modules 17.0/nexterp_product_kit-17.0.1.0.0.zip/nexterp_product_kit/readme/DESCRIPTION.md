This module allows you define product kits from products marked as
components.
