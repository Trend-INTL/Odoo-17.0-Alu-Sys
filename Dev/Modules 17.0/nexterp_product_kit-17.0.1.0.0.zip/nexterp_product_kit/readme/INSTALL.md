To install this module, you need to:

- clone the branch 17.0 of the repository
  <https://github.com/NextERP-Romania/odoo-community>
- add the path to this repository in your configuration (addons-path)
- update the module list
- search for "NextERP - Product Kit" in your addons
- install the module
