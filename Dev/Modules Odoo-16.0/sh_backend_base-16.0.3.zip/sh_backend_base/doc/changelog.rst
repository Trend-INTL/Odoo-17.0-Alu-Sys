16.0.1 (27th Feb 2023)
-----------------------
- Initial Release

16.0.2 (21st April 2023)
------------------------
- Small Bug Fix

16.0.3 (12-8-2023)
--------------------
- Add Custom Font icon (Icomoon)

(28-8-2023)
--------------------
- Added new Custom font icon.