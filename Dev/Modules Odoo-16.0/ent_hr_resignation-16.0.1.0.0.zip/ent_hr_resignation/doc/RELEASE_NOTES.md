## Module <ent_hr_resignation>

#### 10.11.2022
#### Version 16.0.1.0.0
##### ADD
- Initial Commit for Enterprise OHRMS HR resignation module V16
