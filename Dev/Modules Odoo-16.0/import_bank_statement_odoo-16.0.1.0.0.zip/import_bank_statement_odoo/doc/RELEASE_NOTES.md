## Module <import_bank_statement_odoo>
#### 04.11.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Import Bank Statement
