## Module <dynamic_accounts_report>

#### 02.09.2022
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Odoo 16 dynamic financial reports

#### 01.02.2023
#### Version 16.0.1.0.1
#### UPDT
- CSS file updated

#### 07.02.2023
#### Version 16.0.1.0.2
#### UPDT AND BUGFIX
- Report Bug Fix: Correct the currency used in the General Ledger

#### 21.04.2023
#### Version 16.0.1.0.5
#### BUGFIX
- Report Bug Fix: Journal filter is not visible for any languages other than english, entries of all journals are taken for bank book and cash book for other languages.

#### 24.08.2023
#### Version 16.0.1.0.6
#### BUGFIX
- Report Bug Fix: The issues with the analytic filter in the general ledger, partner ledger, and profit and loss statement have been fixed, and the problem with language while printing reports has also been addressed.

#### 18.09.2023
#### Version 16.0.1.0.7
#### BUGFIX
- Report Bug Fix: Problem with language while printing profit and loss report fixed.
- Report Bug Fix: Problem with language while opening cash flow statement.

### 20.11.2023
### version 16.0.1.0.9,
### BUGFIX
- Profit And Loss:  multiple lines of the same account in the financial reports.

### 11.12.2023
### version 16.0.1.0.10,
### BUGFIX
- Profit And Loss:  multiple lines of the same account in the financial reports.

### 11.12.2023
### version 16.0.1.0.11,
### BUGFIX
- General Ledger: Fixed the Redundancy bug 
